document.getElementById('location-form').addEventListener('submit', getWeather);

async function getWeather(e) {
  e.preventDefault();
  const weatherData = document.getElementById('weather-data');
  const locationFetched = document.getElementById("location-input").value;
  console.log(locationFetched)
  if(!locationFetched){
    weatherData.innerHTML = "<h3>Please enter location!!</h3>";
    return;
  }
  try{
    const responseJSON = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=${locationFetched}&APPID=448f8eec7cf72faa9907acdbd5da3e55`);
    const responseValue = await responseJSON.json();
    console.log(responseValue)
    let location = responseValue.name;
    let weatherCondition = responseValue.weather[0].main;
    let tempAtLocation = Math.round(((responseValue.main.temp - 273.15)*100)/100).toFixed(2);
    weatherData.innerHTML = `<div>
                              <h3>${location}</h3>
                              <h4>${weatherCondition}</h4>
                              <p>${tempAtLocation}°C</p>
                              </div>`;
  }catch(err){
    weatherData.innerHTML = "<h3>Error: City not found</h3>";
  }  
}

// document.getElementById('location-form').reset();
